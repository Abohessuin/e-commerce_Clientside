import React, { useEffect, useState, useRef } from "react";
import { useFrame, useThree } from "react-three-fiber";
import * as THREE from "three";
import { Html } from "drei";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
import { Object3D } from "three/src/core/Object3D"; //Object3D types
import { AnimationClip } from "three/src/animation/AnimationClip"; //Animation types
import { Scene, TextureLoader } from "three";

const Model = () => {
  /* Refs */

  const textureLoader = new THREE.TextureLoader();
  /* State */
  const [model, setModel] = useState();

  /* Mixer */
  // const [mixer] = useState(() => new THREE.AnimationMixer(null));
  const scene = new THREE.Scene();

  const renderer = useThree(); 
  /* Load model */
  useEffect(() => {
    const loader = new GLTFLoader();
    // loader.load("Scene_Merged_Materials_For_Dynamic_Lighting.gltf", async (gltf) => {
    // loader.load("Scene_Apartments_Buildings.gltf", async (gltf) => {
    loader.load(
      "assets/models/Scene_Merged_Buildings_and_Boxes.gltf",
      async (gltf) => {
        console.log(gltf);
        const nodes = await gltf.parser.getDependencies("node");
        
        nodes.forEach((node) => {
          var vis = true;
          if (node.name.includes("Box")){
            vis = false;
          }
          const textureObject = textureLoader.load("assets/textures/" + node.name + ".jpg");
          textureObject.flipY = false;
          textureObject.encoding = THREE.sRGBEncoding;
          renderer.outputEncoding = THREE.sRGBEncoding;

          if (node.isMesh) {
            node.material = new THREE.MeshBasicMaterial({
              // color: 'white',    // red (can also use a CSS color string here)
              // flatShading: false,
              map: textureObject,
              visible: vis
            });
            scene.add(node)
          }
        })
        // use THREE.sRGBEncoding
// TextureLoader.load("image path")
        // renderer.outputEncoding = 

        // scene.add(gltf.scene);
        console.log(nodes);
        console.log(scene);
        // const animations = await gltf.parser.getDependencies("animation");
        setModel(scene);
        // setAnimation(animations);
      }
    );
  }, []);

  return (
    <>
      {model ? (
        <group position={[0, 0, 0]} dispose={null}>
          <primitive name="Object_0" object={model} />
        </group>
      ) : (
        <Html>Loading...</Html>
      )}
    </>
  );
};

export default Model;
