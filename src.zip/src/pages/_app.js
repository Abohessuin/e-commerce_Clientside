import "../../public/assets/css/index.css";
import "../../public/assets/css/styles.css";

const MyApp = ({ Component, pageProps }) => {
  return <Component {...pageProps} />;
};
export default MyApp;
