import { Canvas, extend, useThree } from "react-three-fiber";
import Lights from "../components/Light";
import Model from "../components/Model";
import Orbit from "../components/Orbit";

const Home = () => {
  return (
    <>
      <Canvas
        style={{ background: "grey", width: "100vw", height: "100vh" }}
        colorManagement
        camera={{ position: [0, 0, 300] }}
        shadowMap
      >
        {/* <Lights /> */}
        <Model />
        <Orbit />
      </Canvas>
    </>
  );
};

export default Home;
